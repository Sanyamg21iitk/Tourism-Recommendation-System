from django.contrib import admin
from .models import *


# Register your models here.


admin.site.register(plotsector)
admin.site.register(userfavs)
admin.site.register(comfavs)