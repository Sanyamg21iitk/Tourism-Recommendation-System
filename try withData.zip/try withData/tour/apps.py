from django.apps import AppConfig


class TourConfig(AppConfig):
    name = 'tour'
